/*
Libreria para creacion de cadenas CODIFICADAS que seran enviadas a a broker MQTT por medio del sistema Embebido ESP32
Creada por: Brian Sánchez Izquierdo, 02 de Octubre del 2019
Modificada por :Pablo Garcia Jimenez Aka GOOEX, 07 de Octubre del 2021
Para ACCESA.me
*/

//#ifndef enviosWebSocketyCAN_h
//#define enviosWebSocketyCAN_h
#ifndef enviosMQTTyCAN_h
#define enviosMQTTyCAN_h

#include "Arduino.h"
#include <ESP32CAN.h>
#include <CAN_config.h>

class EnvioMqtt{
  
  public:
    
    void  envioLatido(CAN_frame_t *rx_frame, char *cadenaEnviar);
    void  envioActivacion(CAN_frame_t *rx_frame, char* cadenaEnviar);
    void  envioBorraEscenario(CAN_frame_t *rx_frame, char *cadenaEnviar);
    void  envioConfiguracionEscenario(CAN_frame_t *rx_frame, char *cadenaEnviar);
    void  envioCambioFecha(CAN_frame_t *rx_frame, char *cadenaEnviar);
    void  envioEjecucionEscenario(CAN_frame_t *rx_frame, char *cadenaEnviar);
    void  envioCambioCAN(CAN_frame_t *rx_frame, char *cadenaEnviar);
    void  envioConfiguracionTarjeta(CAN_frame_t *rx_frame, char *cadenaEnviar);

  private:
    char  dirCANws[3], dirRespuesta[3], numEscenarioRespuesta[3];
};

class EnvioCAN{
  
  public:
  byte  x2i(char *cadena);
  void  envioActivacion(String cadenaWebSocket, CAN_frame_t *estructuraCAN);
  void  instruccionesEscenario(String cadenaEscenario, CAN_frame_t *estructuraCAN, byte posicionDeInstruccion);
  void  configuraEscenarioInstantaneo(String cadenaEscenario, CAN_frame_t *estructuraCAN);
  void  configuraEscenarioDia(String cadenaEscenario, CAN_frame_t *estructuraCAN);
  void  configuraEscenarioFechaInicio(String cadenaEscenario, CAN_frame_t *estructuraCAN);
  void  configuraEscenarioFechaFin(String cadenaEscenario, CAN_frame_t *estructuraCAN);
  void  envioConfiguracionTarjetaEntrada(String cadenaConfiguracion, CAN_frame_t *estructuraCAN);
  void  envioBorraEscenario(String cadenaWebSocket, CAN_frame_t *estructuraCAN);
  void  envioConfiguracionEscenario(String cadenaEscenario, CAN_frame_t *estructuraCAN);
  void  envioCambioFecha(String cadenaWebSocket, CAN_frame_t *estructuraCAN);
  void  envioEjecucionEscenario(String cadenaWebSocket, CAN_frame_t *estructuraCAN);
  void  envioCambioCAN(String cadenaWebSocket, CAN_frame_t *estructuraCAN);
  bool  envioConfigurarTarjeta(String cadenaConfiguracion, CAN_frame_t *estructuraCAN);
  
  byte  numInstrucciones;
  
  private:
  char tarjetaEnlace[3], tiempo[3], porcentaje[4], numeroEscenario[3];
  byte dirCAN, tiempoByte, porcentajeByte, numEscenario;
};

#endif

