#include "creacionEnviosMQTTyCAN.h"
#include  "Arduino.h"



void EnvioMqtt::envioLatido(CAN_frame_t *rx_frame, char *cadenaEnviar){
  
  //dirRespuesta=[];
  
  cadenaEnviar[2] = rx_frame->data.u8[0];                                             //INSTRUCCIÓN
  sprintf(dirCANws, "%.2X", rx_frame->MsgID);
  cadenaEnviar[0] = dirCANws[0];
  cadenaEnviar[1] = dirCANws[1];
  sprintf(dirRespuesta, "%.2X", rx_frame->data.u8[1]);
  cadenaEnviar[3] = dirRespuesta[0];
  cadenaEnviar[4] = dirRespuesta[1];
  for(byte i=0; i<8; i++){
    cadenaEnviar[5+i] = rx_frame->data.u8[2];
  }
  cadenaEnviar[14] = '\0';
  Serial.println("TRANSMISIÓN MQTT:");
  Serial.println(cadenaEnviar);
}

void EnvioMqtt::envioActivacion(CAN_frame_t *rx_frame, char *cadenaEnviar){
  
  char porcentajeRespuesta[4], tiempoRespuesta[3];
  char respuestaRojo[2], respuestaVerde[2], respuestaAzul[2];
  
  sprintf(dirCANws, "%.2X", rx_frame->MsgID);
  cadenaEnviar[0] = dirCANws[0];                                   //DIR ENLACE
  cadenaEnviar[1] = dirCANws[1];                                   //DIR ENLACE
  //sprintf("dirCANws :",dirCANws);                             // ----------debug----------
  cadenaEnviar[2] = char(rx_frame->data.u8[0]);             //INSTRUCCION
  
  sprintf(dirRespuesta, "%.2X", rx_frame->data.u8[1]);
  cadenaEnviar[3] = dirRespuesta[0];                               //DIR TARJETA EXE
  cadenaEnviar[4] = dirRespuesta[1];                               //DIR TARJETA EXE
  cadenaEnviar[5] = rx_frame->data.u8[2];                           //PIN
  //sprintf("dirRespuesta :",dirRespuesta);                             // ----------debug----------

  //CASO FOCO
  if(char(rx_frame->data.u8[7]) == 'x'){
   sprintf(porcentajeRespuesta, "%.3i", rx_frame->data.u8[3]);
   cadenaEnviar[6] = porcentajeRespuesta[0];                       //PORCENTAJE
   cadenaEnviar[7] = porcentajeRespuesta[1];                       //PORCENTAJE
   cadenaEnviar[8] = porcentajeRespuesta[2];                       //PORCENTAJE
  //sprintf("porcentajeRespuesta :",porcentajeRespuesta);              // ----------debug----------

   sprintf(tiempoRespuesta, "%.2i", rx_frame->data.u8[4]);
   cadenaEnviar[9] = tiempoRespuesta[0];                           //TIEMPO
   cadenaEnviar[10] = tiempoRespuesta[1];                          //TIEMPO
   //sprintf("tiempoRespuesta :",tiempoRespuesta);                     // ----------debug----------
   
   cadenaEnviar[11] = rx_frame->data.u8[5];                         //X
   cadenaEnviar[12] = rx_frame->data.u8[6];                         //X
   cadenaEnviar[13] = rx_frame->data.u8[7];                         //X
   cadenaEnviar[14] = '\0';
  }
  //CASO RGB
  else{
    cadenaEnviar[6] = rx_frame->data.u8[3];                         //x
    cadenaEnviar[7] = rx_frame->data.u8[3];
    cadenaEnviar[8] = rx_frame->data.u8[3];
    sprintf(tiempoRespuesta, "%.2i", rx_frame->data.u8[4]);
    cadenaEnviar[9] = tiempoRespuesta[0];                          //TIEMPO
    cadenaEnviar[10] = tiempoRespuesta[1];                         //TIEMPO
    sprintf(respuestaRojo, "%.1X", rx_frame->data.u8[5]);
    cadenaEnviar[11] = respuestaRojo[0];                                      //R
    sprintf(respuestaVerde, "%.1X", rx_frame->data.u8[6]);
    cadenaEnviar[12] = respuestaVerde[0];                                      //G
    sprintf(respuestaAzul, "%.1X", rx_frame->data.u8[7]);
    cadenaEnviar[13] = respuestaAzul[0];                                      //B
    cadenaEnviar[14] = '\0';
  }
  Serial.println("ENVIO MQTT:");
  Serial.println(cadenaEnviar);
  //return cadenaEnviar;
}

void EnvioMqtt::envioBorraEscenario(CAN_frame_t *rx_frame, char *cadenaEnviar){ 
  
  sprintf(dirCANws, "%.2X", rx_frame->MsgID);
  cadenaEnviar[0] = dirCANws[0];                                   //DIR ENLACE
  cadenaEnviar[1] = dirCANws[1];                                   //DIR ENLACE
  cadenaEnviar[2] = char(rx_frame->data.u8[0]);                     //INSTRUCCION
  sprintf(dirRespuesta, "%.2i", rx_frame->data.u8[1]);
  cadenaEnviar[3] = dirRespuesta[0];                               //DIR TARJETA EXE
  cadenaEnviar[4] = dirRespuesta[1];                               //DIR TARJETA EXE
  cadenaEnviar[5] = 'E';
  cadenaEnviar[6] = 'S';
  cadenaEnviar[7] = 'C';
  sprintf(numEscenarioRespuesta, "%.2i", rx_frame->data.u8[2]);
  cadenaEnviar[8] = numEscenarioRespuesta[0];
  cadenaEnviar[9] = numEscenarioRespuesta[1];
  cadenaEnviar[10] = '\0';
  Serial.println("ENVIO MQTT:");
  Serial.println(cadenaEnviar);
}

void EnvioMqtt::envioConfiguracionEscenario(CAN_frame_t *rx_frame, char *cadenaEnviar){

  sprintf(dirCANws, "%.2X", rx_frame->MsgID);
  cadenaEnviar[0] = dirCANws[0];                                   //DIR ENLACE
  cadenaEnviar[1] = dirCANws[1];                                   //DIR ENLACE
  cadenaEnviar[2] = char(rx_frame->data.u8[0]);                     //INSTRUCCION
  sprintf(dirRespuesta, "%.2i", rx_frame->data.u8[1]);
  cadenaEnviar[3] = dirRespuesta[0];                               //DIR TARJETA EXE
  cadenaEnviar[4] = dirRespuesta[1];                               //DIR TARJETA EXE
  cadenaEnviar[5] = 'E';
  cadenaEnviar[6] = 'S';
  cadenaEnviar[7] = 'C';
  sprintf(numEscenarioRespuesta, "%.2i", rx_frame->data.u8[2]);
  cadenaEnviar[8] = numEscenarioRespuesta[0];
  cadenaEnviar[9] = numEscenarioRespuesta[1];
  cadenaEnviar[10] = '\0';
  Serial.println("ENVIO MQTT:");
  Serial.println(cadenaEnviar);
}

void EnvioMqtt::envioCambioFecha(CAN_frame_t *rx_frame, char *cadenaEnviar){
  
  sprintf(dirCANws, "%.2X", rx_frame->MsgID);
  cadenaEnviar[0] = dirCANws[0];                                   //DIR ENLACE
  cadenaEnviar[1] = dirCANws[1];                                   //DIR ENLACE
  cadenaEnviar[2] = char(rx_frame->data.u8[0]);                     //INSTRUCCION
  sprintf(dirRespuesta, "%.2i", rx_frame->data.u8[1]);
  cadenaEnviar[3] = dirRespuesta[0];                               //DIR TARJETA EXE
  cadenaEnviar[4] = dirRespuesta[1];                               //DIR TARJETA EXE
  for(byte h=0 ; h <8; h++){
    cadenaEnviar[5+h] = 'x';
  }
  cadenaEnviar[14] = '\0';
  Serial.println("ENVIO MQTT:");
  Serial.println(cadenaEnviar);
}

void EnvioMqtt::envioEjecucionEscenario(CAN_frame_t *rx_frame, char *cadenaEnviar){

  sprintf(dirCANws, "%.2X", rx_frame->MsgID);
  cadenaEnviar[0] = dirCANws[0];                                   //DIR ENLACE
  cadenaEnviar[1] = dirCANws[1];                                   //DIR ENLACE
  cadenaEnviar[2] = char(rx_frame->data.u8[0]);                     //INSTRUCCION
  sprintf(dirRespuesta, "%.2i", rx_frame->data.u8[1]);
  cadenaEnviar[3] = dirRespuesta[0];                               //DIR TARJETA EXE
  cadenaEnviar[4] = dirRespuesta[1];                               //DIR TARJETA EXE
  cadenaEnviar[5] = 'E';
  cadenaEnviar[6] = 'S';
  cadenaEnviar[7] = 'C';
  sprintf(numEscenarioRespuesta, "%.2i", rx_frame->data.u8[2]);
  cadenaEnviar[8] = numEscenarioRespuesta[0];
  cadenaEnviar[9] = numEscenarioRespuesta[1];
  cadenaEnviar[10] = '\0';
  Serial.println("ENVIO MQTT:");
  Serial.println(cadenaEnviar);
}

void EnvioMqtt::envioCambioCAN(CAN_frame_t *rx_frame, char *cadenaEnviar){
  char nuevaDireccionCAN[3];
  cadenaEnviar[2] = rx_frame->data.u8[0];                                             
  sprintf(dirCANws, "%.2X", rx_frame->MsgID);
  cadenaEnviar[0] = dirCANws[0];
  cadenaEnviar[1] = dirCANws[1];
  sprintf(dirRespuesta, "%.2X", rx_frame->data.u8[1]);
  cadenaEnviar[3] = dirRespuesta[0];
  cadenaEnviar[4] = dirRespuesta[1];
  sprintf(nuevaDireccionCAN, "%.2X", rx_frame->data.u8[2]);
  cadenaEnviar[5] = nuevaDireccionCAN[0];
  cadenaEnviar[6] = nuevaDireccionCAN[1];
  for(byte i = 0; i<7; i++){
    cadenaEnviar[6+i] = 'x';
  }
  cadenaEnviar[14] = '\0';
  Serial.println("TRANSMISIÓN MQTT:");
  Serial.println(cadenaEnviar);
}

void EnvioMqtt::envioConfiguracionTarjeta(CAN_frame_t *rx_frame, char *cadenaEnviar){
  
  cadenaEnviar[2] = rx_frame->data.u8[0];
  sprintf(dirCANws, "%.2X", rx_frame->MsgID);
  cadenaEnviar[0] = dirCANws[0];
  cadenaEnviar[1] = dirCANws[1];
  sprintf(dirRespuesta, "%.2X", rx_frame->data.u8[1]);
  cadenaEnviar[3] = dirRespuesta[0];
  cadenaEnviar[4] = dirRespuesta[1];
  cadenaEnviar[5] = 'T';
  cadenaEnviar[6] = 'O';
  cadenaEnviar[7] = 'U';
  cadenaEnviar[8] = 'C';
  cadenaEnviar[9] = 'H';
  cadenaEnviar[10] = '\0';
  Serial.println("TRANSMISIÓN MQTT:");
  Serial.println(cadenaEnviar);
}
/*
              FUNCIONES PARA ENVIO POR CAN
*/
byte EnvioCAN::x2i(char *cadena){
  byte x = 0;
   for(;;) {
     char c = *cadena;
     if (c >= '0' && c <= '9') {
        x *= 16;
        x += c - '0';
     }
     else if (c >= 'A' && c <= 'F') {
        x *= 16;
        x += (c - 'A') + 10;
     }
     else break;
     cadena++;
   }
   return x;
}

void EnvioCAN::configuraEscenarioFechaFin(String cadenaEscenario, CAN_frame_t *estructuraCAN){

  char fechaDiaF[3], fechaMesF[3], fechaAxoF[3];
  byte diaF, mesF, axoF;
  
  estructuraCAN->data.u8[0] = cadenaEscenario[2];                            //INSTRUCCION (2.- Instrucciones)
  Serial.print(char(estructuraCAN->data.u8[0]));
  //SEGUNDO BYTE ENVIO CAN
  tarjetaEnlace[0] = cadenaEscenario[0];             
  tarjetaEnlace[1] = cadenaEscenario[1];
  dirCAN = x2i(tarjetaEnlace);
  estructuraCAN->data.u8[1] = dirCAN;                                      //DIRECCIÓN DE TARJETA ENLACE
  Serial.print(estructuraCAN->data.u8[1]);
  //TERCER BYTE ENVIO CAN
  estructuraCAN->data.u8[2] = numEscenario;                                //DIRECCIÓN DE TARJETA ESCENARIOS
  Serial.print(estructuraCAN->data.u8[2]);
  //CUARTO BYTE ENVIO CAN
  fechaDiaF[0] = cadenaEscenario[cadenaEscenario.length() - 12];
  fechaDiaF[1] = cadenaEscenario[cadenaEscenario.length() - 11];
  diaF = atoi(fechaDiaF);
  estructuraCAN->data.u8[3] = diaF;
  Serial.print(estructuraCAN->data.u8[3]);
  //QUINTO BYTE ENVIO CAN
  fechaMesF[0] = cadenaEscenario[cadenaEscenario.length() - 10];
  fechaMesF[1] = cadenaEscenario[cadenaEscenario.length() - 9];
  mesF = atoi(fechaMesF);
  estructuraCAN->data.u8[4] = mesF;
  Serial.print(estructuraCAN->data.u8[4]);
  //SEXTO BYTE ENVIO CAN
  fechaAxoF[0] = cadenaEscenario[cadenaEscenario.length() - 8];
  fechaAxoF[1] = cadenaEscenario[cadenaEscenario.length() - 7];
  axoF = atoi(fechaAxoF);
  estructuraCAN->data.u8[5] = axoF;
  Serial.print(estructuraCAN->data.u8[5]);
  //RESTO ENVIO CAN
  for(byte k=0; k<2; k++){
    estructuraCAN->data.u8[6+k] = 'x';
    Serial.print(estructuraCAN->data.u8[6+k]);
  }
}

void EnvioCAN::configuraEscenarioFechaInicio(String cadenaEscenario, CAN_frame_t *estructuraCAN){

  char fechaDiaI[3], fechaMesI[3], fechaAxoI[3], hora[3], minuto[3];
  byte diaI, mesI, axoI, horaByte, minutoByte;
  
  estructuraCAN->data.u8[0] = cadenaEscenario[2];                               //INSTRUCCION (2.- Instrucciones)
  Serial.print(char(estructuraCAN->data.u8[0]));
  //SEGUNDO BYTE ENVIO CAN
  tarjetaEnlace[0] = cadenaEscenario[0];             
  tarjetaEnlace[1] = cadenaEscenario[1];
  dirCAN = x2i(tarjetaEnlace);
  estructuraCAN->data.u8[1] = dirCAN;                                         //DIRECCIÓN DE TARJETA ENLACE
  Serial.print(estructuraCAN->data.u8[1]);
  //TERCER BYTE ENVIO CAN
  estructuraCAN->data.u8[2] = numEscenario;                                   //DIRECCIÓN DE TARJETA ESCENARIOS
  Serial.print(estructuraCAN->data.u8[2]);
  //CUARTO BYTE ENVIO CAN
  fechaDiaI[0] = cadenaEscenario[cadenaEscenario.length() - 19];
  fechaDiaI[1] = cadenaEscenario[cadenaEscenario.length() - 18];
  diaI = atoi(fechaDiaI);
  estructuraCAN->data.u8[3] = diaI;
  Serial.print(estructuraCAN->data.u8[3]);
  //QUINTO BYTE ENVIO CAN
  fechaMesI[0] = cadenaEscenario[cadenaEscenario.length() - 17];
  fechaMesI[1] = cadenaEscenario[cadenaEscenario.length() - 16];
  mesI = atoi(fechaMesI);
  estructuraCAN->data.u8[4] = mesI;
  Serial.print(estructuraCAN->data.u8[4]);
  //SEXTO BYTE ENVIO CAN
  fechaAxoI[0] = cadenaEscenario[cadenaEscenario.length() - 15];
  fechaAxoI[1] = cadenaEscenario[cadenaEscenario.length() - 14];
  axoI = atoi(fechaAxoI);
  estructuraCAN->data.u8[5] = axoI;
  Serial.print(estructuraCAN->data.u8[5]);
  //SEPTIMO BYTE ENVIO CAN
  hora[0] = cadenaEscenario[cadenaEscenario.length() - 5];
  hora[1] = cadenaEscenario[cadenaEscenario.length() - 4];
  horaByte = atoi(hora);
  estructuraCAN->data.u8[6] = horaByte;
  Serial.print(estructuraCAN->data.u8[6]);
  //OCTAVO BYTE ENVIO CAN
  minuto[0] = cadenaEscenario[cadenaEscenario.length() - 3];
  minuto[1] = cadenaEscenario[cadenaEscenario.length() - 2];
  minutoByte = atoi(minuto);
  estructuraCAN->data.u8[7] = minutoByte;
  Serial.print(estructuraCAN->data.u8[7]);
}

void EnvioCAN::configuraEscenarioDia(String cadenaEscenario, CAN_frame_t *estructuraCAN){

  char cadenaBIN[8];
  
  //PRIMER BYTE ENVIO CAN
  estructuraCAN->data.u8[0] = cadenaEscenario[2];                                    //INSTRUCCION (2.- Instrucciones)
  Serial.print(char(estructuraCAN->data.u8[0]));
  //SEGUNDO BYTE ENVIO CAN
  tarjetaEnlace[0] = cadenaEscenario[0];             
  tarjetaEnlace[1] = cadenaEscenario[1];
  dirCAN = x2i(tarjetaEnlace);
  estructuraCAN->data.u8[1] = dirCAN;                                              //DIRECCIÓN DE TARJETA ENLACE
  Serial.print(estructuraCAN->data.u8[1]);
  //TERCER BYTE ENVIO CAN
  estructuraCAN->data.u8[2] = numEscenario;                                        //DIRECCIÓN DE TARJETA ESCENARIOS
  Serial.print(estructuraCAN->data.u8[2]);
  //CUARTO BYTE ENVIO CAN
  cadenaBIN[0] = cadenaEscenario[cadenaEscenario.length() - 7];
  cadenaBIN[1] = cadenaEscenario[cadenaEscenario.length() - 8];
  cadenaBIN[2] = cadenaEscenario[cadenaEscenario.length() - 9];
  cadenaBIN[3] = cadenaEscenario[cadenaEscenario.length() - 10];
  cadenaBIN[4] = cadenaEscenario[cadenaEscenario.length() - 11];
  cadenaBIN[5] = cadenaEscenario[cadenaEscenario.length() - 12];
  cadenaBIN[6] = cadenaEscenario[cadenaEscenario.length() - 13];
  byte diasBin = strtol(cadenaBIN, 0, 2);
  estructuraCAN->data.u8[3] = diasBin;
  Serial.print(estructuraCAN->data.u8[3]);
  //QUINTO BYTE ENVIO CAN
  char hora[3];
  hora[0] = cadenaEscenario[cadenaEscenario.length() - 5];
  hora[1] = cadenaEscenario[cadenaEscenario.length() - 4];
  byte horabyte = atoi(hora);
  
  estructuraCAN->data.u8[4] = horabyte;
  Serial.print(estructuraCAN->data.u8[4]);
  //SEXTO BYTE ENVIO CAN
  char minuto[3];
  minuto[0] = cadenaEscenario[cadenaEscenario.length() - 3];
  minuto[1] = cadenaEscenario[cadenaEscenario.length() - 2];
  byte minutobyte = atoi(minuto);
  estructuraCAN->data.u8[5] = minutobyte;
  Serial.print(estructuraCAN->data.u8[5]);
  //RESTO BYTE ENVIO CAN
  for(int l=0 ; l<2; l++){
    estructuraCAN->data.u8[6+l] = 'x';
    Serial.print(estructuraCAN->data.u8[6+l]);
  }
}

void EnvioCAN::configuraEscenarioInstantaneo(String cadenaEscenario, CAN_frame_t *estructuraCAN){
  
  //PRIMER BYTE ENVIO CAN
  estructuraCAN->data.u8[0] = cadenaEscenario[2];                                    //INSTRUCCION (2.- Instrucciones)
  Serial.print(char(estructuraCAN->data.u8[0]));
  //SEGUNDO BYTE ENVIO CAN
  tarjetaEnlace[0] = cadenaEscenario[0];             
  tarjetaEnlace[1] = cadenaEscenario[1];
  dirCAN = x2i(tarjetaEnlace);
  estructuraCAN->data.u8[1] = dirCAN;                                              //DIRECCIÓN DE TARJETA ENLACE
  Serial.print(estructuraCAN->data.u8[1]);
  //TERCER BYTE ENVIO CAN
  estructuraCAN->data.u8[2] = numEscenario;                                        //DIRECCIÓN DE TARJETA ESCENARIOS
  Serial.print(estructuraCAN->data.u8[2]);
  //CUARTO BYTE ENVIO CAN
  estructuraCAN->data.u8[3] = 0;
  Serial.print(estructuraCAN->data.u8[3]);
  //RESTO
  for(int j=0 ; j<4; j++){
    estructuraCAN->data.u8[j+4] = 'x';
    Serial.print(estructuraCAN->data.u8[j+4]);
  }
}

void EnvioCAN::instruccionesEscenario(String cadenaEscenario, CAN_frame_t *estructuraCAN, byte posicionDeInstruccion){
  
  char tarjetaEscenario[3], R[2], G[2], B[2];
  byte dirEscenario;
  
  //PRIMER BYTE ENVIO CAN
  estructuraCAN->data.u8[0] = cadenaEscenario[2];                                 //INSTRUCCION (2.- Instrucciones)
  Serial.print(char(estructuraCAN->data.u8[0]));
  //SEGUNDO BYTE ENVIO CAN
  tarjetaEnlace[0] = cadenaEscenario[0];             
  tarjetaEnlace[1] = cadenaEscenario[1];
  dirCAN = x2i(tarjetaEnlace);
  estructuraCAN->data.u8[1] = dirCAN;                                           //DIRECCIÓN DE TARJETA ENLACE
  Serial.print(estructuraCAN->data.u8[1]);
  //TERCER BYTE ENVIO CAN
  tarjetaEscenario[0] = cadenaEscenario[14+(posicionDeInstruccion*12)];
  tarjetaEscenario[1] = cadenaEscenario[15+(posicionDeInstruccion*12)];
  dirEscenario = x2i(tarjetaEscenario);
  estructuraCAN->data.u8[2] = dirEscenario;                                     //DIRECCIÓN DE TARJETA ESCENARIOS
  Serial.print(estructuraCAN->data.u8[2]);
  //CUARTO BYTE ENVIO CAN
  estructuraCAN->data.u8[3] = cadenaEscenario[16+(posicionDeInstruccion*12)];           //PIN
  Serial.print(char(estructuraCAN->data.u8[3]));
  //QUINTO BYTE ENVIO CAN
  tiempo[0] = cadenaEscenario[20 +(posicionDeInstruccion*12)];
  tiempo[1] = cadenaEscenario[21 +(posicionDeInstruccion*12)];
  tiempoByte = atoi(tiempo);
  estructuraCAN->data.u8[4] = tiempoByte;                                       //TIEMPO
  Serial.print(estructuraCAN->data.u8[4]);
  if(cadenaEscenario[19 +(posicionDeInstruccion*12)] != 'x'){
    //CASO FOCO, PREGUNTO POR EL CONTENIDO [19 +(posicionDeInstruccion*12)] PORQUE EN ESA POSICIÓN SIEMPRE ESTARA EL ULTIMO DIGITO DE PORCENTAJE, QUE EN DADO CASO DE SER 'x', SE SABRA QUE LA INSTRUCCIÓN ES PARA RGB.              
    //SEXTO BYTE ENVIO CAN
    porcentaje[0] = cadenaEscenario[17 +(posicionDeInstruccion*12)];
    porcentaje[1] = cadenaEscenario[18 +(posicionDeInstruccion*12)];
    porcentaje[2] = cadenaEscenario[19 +(posicionDeInstruccion*12)];
    porcentajeByte = atoi(porcentaje);
    estructuraCAN->data.u8[5] = porcentajeByte;                                 //PORCENTAJE
    Serial.print(estructuraCAN->data.u8[5]);
    //SEPTIMO BYTE ENVIO CAN
    estructuraCAN->data.u8[6] = 'x';
    Serial.print(char(estructuraCAN->data.u8[6]));
    //OCTAVO BYTE ENVIO CAN
    estructuraCAN->data.u8[7] = 'x';
    Serial.print(char(estructuraCAN->data.u8[7]));
    }
    else{//CASO RGB
      //SEXTO BYTE ENVIO CAN 
      R[0] = cadenaEscenario[22 + (posicionDeInstruccion * 12)];
      estructuraCAN->data.u8[5] = cadenaEscenario[22 + (posicionDeInstruccion * 12)];                                             //R
      Serial.print(estructuraCAN->data.u8[5]);
      //SEPTIMO BYTE ENVIO CAN
      G[0] = cadenaEscenario[23 + (posicionDeInstruccion * 12)];
      estructuraCAN->data.u8[6] = cadenaEscenario[23 + (posicionDeInstruccion * 12)];                                             //G
      Serial.print(estructuraCAN->data.u8[6]);
      //OCTAVO BYTE ENVIO CAN
      B[0] = cadenaEscenario[24 + (posicionDeInstruccion * 12)];
      estructuraCAN->data.u8[7] = cadenaEscenario[24 + (posicionDeInstruccion * 12)];                                             //B
      Serial.print(estructuraCAN->data.u8[7]);
    }
}

void EnvioCAN::envioConfiguracionEscenario(String cadenaEscenario, CAN_frame_t *estructuraCAN){

  char numeroInstrucciones[3];
  
  //PRIMER BYTE ENVIO CAN
  estructuraCAN->data.u8[0] = cadenaEscenario[2];
  //SEGUNDO BYTE ENVIO CAN
  tarjetaEnlace[0] = cadenaEscenario[0];             
  tarjetaEnlace[1] = cadenaEscenario[1];
  dirCAN = x2i(tarjetaEnlace);
  estructuraCAN->data.u8[1] = dirCAN;                                 //DIRECCIÓN DE TARJETA ENLACE     
  //TERCER ENVIO CAN
  numeroEscenario[0] = cadenaEscenario[9];
  numeroEscenario[1] = cadenaEscenario[10];
  numEscenario = atoi(numeroEscenario);
  estructuraCAN->data.u8[2] = numEscenario;
  //CUARTO ENVIO CAN
  numeroInstrucciones[0] = cadenaEscenario[12];
  numeroInstrucciones[1] = cadenaEscenario[13];
  numInstrucciones = atoi(numeroInstrucciones);
  estructuraCAN->data.u8[3] = numInstrucciones;
  //RESTO DEL ENVIO;
  for(int j=0; j<4; j++){
    estructuraCAN->data.u8[4+j] = 'x';
  }
  
  Serial.print(char(estructuraCAN->data.u8[0]));
  Serial.print(estructuraCAN->data.u8[1]);
  Serial.print(estructuraCAN->data.u8[2]);
  Serial.print(estructuraCAN->data.u8[3]);
  for(int j=0; j<4; j++){
    Serial.print(char(estructuraCAN->data.u8[4+j]));
  }
}

void EnvioCAN::envioActivacion(String cadenaMqtt, CAN_frame_t *estructuraCAN){
  char R[3], G[3], B[3];
  byte r,g,b;
  
  //PRIMER BYTE ENVIO CAN
  estructuraCAN->data.u8[0] = cadenaMqtt[2];
  Serial.print(char(estructuraCAN->data.u8[0]));
  Serial.print("|");
  //SEGUNDO BYTE ENVIO CAN
  tarjetaEnlace[0] = cadenaMqtt[0];               //DIRECCIÓN DE TARJETA ENLACE
  tarjetaEnlace[1] = cadenaMqtt[1];
  dirCAN = x2i(tarjetaEnlace);
  estructuraCAN->data.u8[1] = dirCAN;
  Serial.print( estructuraCAN->data.u8[1]); 
  Serial.print("|");
  //TERCER BYTE ENVIO CAN
  if(cadenaMqtt[8] == 'x'){                       //CASO PRA RGB
    Serial.println("RGB");
    estructuraCAN->data.u8[2] = cadenaMqtt[5];          //PIN
    Serial.print(char(estructuraCAN->data.u8[2]));
    Serial.print("|");
    //CUARTO BYTE ENVIO CAN
    estructuraCAN->data.u8[3] = cadenaMqtt[8];          //PORCENTAJE (nulo)
    Serial.print(estructuraCAN->data.u8[3]);
    Serial.print("|");
    //QUINTO BYTE ENVIO CAN
    tiempo[0] = cadenaMqtt[9];
    tiempo[1] = cadenaMqtt[10];
    tiempoByte = atoi(tiempo);
    estructuraCAN->data.u8[4] = tiempoByte;       //TIEMPO
    Serial.print(estructuraCAN->data.u8[4]);
    Serial.print("|");
    //SEXTO BYTE ENVIO CAN
    estructuraCAN->data.u8[5] = cadenaMqtt[11];               //R
    /*R[0] = cadenaMqtt[11];
    R[1] = cadenaMqtt[12];
    r = x2i(R);
    estructuraCAN->data.u8[5] = r;*/
    Serial.print(estructuraCAN->data.u8[5]);
    Serial.print("|");
    //SEPTIMO BYTE ENVIO CAN
    estructuraCAN->data.u8[6] = cadenaMqtt[12];               //G
    /*G[0] = cadenaMqtt[13];
    G[1] = cadenaMqtt[14];
    g = x2i(G);
    estructuraCAN->data.u8[6] = g;*/
    Serial.print(estructuraCAN->data.u8[6]);
    Serial.print("|");
    //OCTAVO BYTE ENVIO CAN
    estructuraCAN->data.u8[7] = cadenaMqtt[13];               //B
    /*B[0] = cadenaMqtt[15];
    B[1] = cadenaMqtt[16];
    b = x2i(B);
    estructuraCAN->data.u8[7] = b;*/
    Serial.print(estructuraCAN->data.u8[7]);

  }else{                                    //CASO PARA FOCO
    estructuraCAN->data.u8[2] = cadenaMqtt[5];          //PIN
    Serial.print(char(estructuraCAN->data.u8[2]));
    //CUARTO BYTE ENVIO CAN
    porcentaje[0] = cadenaMqtt[6];
    porcentaje[1] = cadenaMqtt[7];
    porcentaje[2] = cadenaMqtt[8];
    porcentajeByte = atoi(porcentaje);
    estructuraCAN->data.u8[3] = porcentajeByte; //PORCENTAJE
    Serial.print(estructuraCAN->data.u8[3]);
    //QUINTO BYTE ENVIO CAN
    tiempo[0] = cadenaMqtt[9];
    tiempo[1] = cadenaMqtt[10];
    tiempoByte = atoi(tiempo);
    estructuraCAN->data.u8[4] = tiempoByte;     //TIEMPO
    Serial.print(estructuraCAN->data.u8[4]);
    //SEXTO BYTE ENVIO CAN
    estructuraCAN->data.u8[5] = cadenaMqtt[11];             //R
    Serial.print(estructuraCAN->data.u8[5]);
    //SEPTIMO BYTE ENVIO CAN
    estructuraCAN->data.u8[6] = cadenaMqtt[12];             //G
    Serial.print(estructuraCAN->data.u8[6]);
    //OCTAVO BYTE ENVIO CAN
    estructuraCAN->data.u8[7] = cadenaMqtt[13];             //B
    Serial.print(estructuraCAN->data.u8[7]);
  }
}

bool EnvioCAN::envioConfigurarTarjeta(String cadenaConfiguracion, CAN_frame_t *estructuraCAN){

  char tarjetaAccion[3], numBoton[3];
  byte dirAccion, numeroBoton;
  
  if(cadenaConfiguracion[cadenaConfiguracion.length() - 2] == ';'){
    Serial.println("TOUCH");
    //PRIMER BYTE ENVIO CAN
    estructuraCAN->data.u8[0] = cadenaConfiguracion[2];         //INSTRUCCION
    Serial.print(char(estructuraCAN->data.u8[0]));
    //SEGUNDO BYTE ENVIO CAN
    tarjetaEnlace[0] = cadenaConfiguracion[0];
    tarjetaEnlace[1] = cadenaConfiguracion[1];
    dirCAN = x2i(tarjetaEnlace);
    estructuraCAN->data.u8[1] = dirCAN;
    Serial.print(estructuraCAN->data.u8[1]);
    //TERCER BYTE ENVIO CAN
    tarjetaAccion[0] = cadenaConfiguracion[10];
    tarjetaAccion[1] = cadenaConfiguracion[11];
    dirAccion = x2i(tarjetaAccion);
    estructuraCAN->data.u8[2] = dirAccion;
    Serial.print(estructuraCAN->data.u8[2]);
    //CUARTO BYTE ENVIO CAN
    estructuraCAN->data.u8[3] = cadenaConfiguracion[12];
    Serial.print(char(estructuraCAN->data.u8[3]));
    //QUINTO BYTE ENVIO CAN
    numBoton[0] = cadenaConfiguracion[16];
    numBoton[1] = cadenaConfiguracion[17];
    numeroBoton = atoi(numBoton);
    estructuraCAN->data.u8[4] = numeroBoton;
    Serial.print(estructuraCAN->data.u8[4]);
    //SEXTO BYTE ENVIO CAN
    estructuraCAN->data.u8[5] = cadenaConfiguracion[18];
    Serial.print(char(estructuraCAN->data.u8[5]));
    //SEPTIMO BYTE ENVIO CAN
    estructuraCAN->data.u8[6] = cadenaConfiguracion[19];
    Serial.print(char(estructuraCAN->data.u8[6]));
    //OCTAVO BYTE ENVIO CAN
    estructuraCAN->data.u8[7] = cadenaConfiguracion[20];
    Serial.print(char(estructuraCAN->data.u8[7])); 
    return false;
  }
  else{
    Serial.println("ENTRADA");
    //PRIMER BYTE ENVIO CAN
    estructuraCAN->data.u8[0] = cadenaConfiguracion[2];
    Serial.print(char(estructuraCAN->data.u8[0]));
    //SEGUNDO BYTE ENVIO CAN
    tarjetaEnlace[0] = cadenaConfiguracion[0];
    tarjetaEnlace[1] = cadenaConfiguracion[1];
    dirCAN = x2i(tarjetaEnlace);
    estructuraCAN->data.u8[1] = dirCAN;
    Serial.print(estructuraCAN->data.u8[1]);
    //TERCER BYTE ENVIO CAN
    estructuraCAN->data.u8[2] = cadenaConfiguracion[7];
    Serial.print(char(estructuraCAN->data.u8[2]));
    //CUARTO BYTE ENVIO CAN
    estructuraCAN->data.u8[3] = cadenaConfiguracion[9];
    //RESTO ENVIO CAN
    for(byte h=0 ; h<3; h++){
      estructuraCAN->data.u8[4+h] = 'x';
      Serial.print(estructuraCAN->data.u8[4+h]);
    }
    return true;
  }
}

void EnvioCAN::envioCambioCAN(String cadenaMqtt, CAN_frame_t *estructuraCAN){

  char newCAN[3];
  byte newCANByte;
  
  //PRIMER BYTE ENVIO CAN
  estructuraCAN->data.u8[0] = cadenaMqtt[2];            //INSTRUCCIÓN
  Serial.print(char(estructuraCAN->data.u8[0]));
  //SEGUNDO BYTE ENVIO CAN
  tarjetaEnlace[0] = cadenaMqtt[0];
  tarjetaEnlace[1] = cadenaMqtt[1];
  dirCAN = x2i(tarjetaEnlace);
  estructuraCAN->data.u8[1] = dirCAN;
  Serial.print(estructuraCAN->data.u8[1]);
  //TERCER BYTE ENVIO CAN
  newCAN[0] = cadenaMqtt[5];
  newCAN[1] = cadenaMqtt[6];
  newCANByte = x2i(newCAN);
  estructuraCAN->data.u8[2] = newCANByte;
  Serial.print(estructuraCAN->data.u8[2]);
  //RESTO ENVIO CAN
  for(byte d=0; d<5; d++){
    estructuraCAN->data.u8[3+d] = 'x';
    Serial.print(estructuraCAN->data.u8[3+d]);
  }
}

void EnvioCAN::envioEjecucionEscenario(String cadenaMqtt, CAN_frame_t *estructuraCAN){
  //PRIMER BYTE ENVIO CAN
  estructuraCAN->data.u8[0] = cadenaMqtt[2];            //INSTRUCCIÓN
  Serial.print(char(estructuraCAN->data.u8[0]));
  //SEGUNDO BYTE ENVIO CAN
  tarjetaEnlace[0] = cadenaMqtt[0];
  tarjetaEnlace[1] = cadenaMqtt[1];
  dirCAN = x2i(tarjetaEnlace);
  estructuraCAN->data.u8[1] = dirCAN;             //DIRECCION DE TARJETA ENLACE
  Serial.print( estructuraCAN->data.u8[1]);
  //TERCER BYTE ENVIO CAN
  numeroEscenario[0] = cadenaMqtt[8];             //NUMERO DE ESCENARIO
  numeroEscenario[1] = cadenaMqtt[9];
  numEscenario = atoi(numeroEscenario);
  estructuraCAN->data.u8[2] = numEscenario;
  Serial.print(estructuraCAN->data.u8[2]);
  //CUARTO BYTE ENVIO CAN
  for(byte i=0; i<5; i++){
    estructuraCAN->data.u8[3+i] = 'x';
    Serial.print(estructuraCAN->data.u8[3+i]);
  }
}

void EnvioCAN::envioCambioFecha(String cadenaMqtt, CAN_frame_t *estructuraCAN){
  
  char dia[3], mes[3], axo[3], hora[3], minuto[3], segundo[3];
  byte diaByte, mesByte, axoByte, horaByte, minutoByte, segundoByte;
  
  //PRIMER BYTE ENVIO CAN
  estructuraCAN->data.u8[0] = cadenaMqtt[2];            //INSTRUCCIÓN
  Serial.print(char(estructuraCAN->data.u8[0]));
  //SEGUNDO BYTE ENVIO CAN
  tarjetaEnlace[0] = cadenaMqtt[0];
  tarjetaEnlace[1] = cadenaMqtt[1];
  dirCAN = x2i(tarjetaEnlace);
  estructuraCAN->data.u8[1] = dirCAN;
  Serial.print(estructuraCAN->data.u8[1]);
  //TERCER BYTE ENVIO CAN
  dia[0] = cadenaMqtt[5];
  dia[1] = cadenaMqtt[6];
  diaByte = atoi(dia);
  estructuraCAN->data.u8[2] = diaByte;
  Serial.print(estructuraCAN->data.u8[2]);
  //CUARTO BYTE ENVIO CAN
  mes[0] = cadenaMqtt[7];
  mes[1] = cadenaMqtt[8];
  mesByte = atoi(mes);
  estructuraCAN->data.u8[3] = mesByte;
  Serial.print(estructuraCAN->data.u8[3]);
  //QUINTO BYTE ENVIO CAN
  axo[0] = cadenaMqtt[9];
  axo[1] = cadenaMqtt[10];
  axoByte = atoi(axo);
  estructuraCAN->data.u8[4] = axoByte;
  //SEXTO BYTE ENVIO CAN
  hora[0] = cadenaMqtt[11];
  hora[1] = cadenaMqtt[12];
  horaByte = atoi(hora);
  estructuraCAN->data.u8[5] = horaByte;
  Serial.print(estructuraCAN->data.u8[5]);
  //SEPTIMO BYTE ENVIO CAN
  minuto[0] = cadenaMqtt[13];
  minuto[1] = cadenaMqtt[14];
  minutoByte = atoi(minuto);
  estructuraCAN->data.u8[6] = minutoByte;
  Serial.print(estructuraCAN->data.u8[6]);
  //OCTAVO BYTE ENVIO CAN
  segundo[0] = cadenaMqtt[15];
  segundo[1] = cadenaMqtt[16];
  segundoByte = atoi(segundo);
  estructuraCAN->data.u8[7] = segundoByte;
  Serial.print(estructuraCAN->data.u8[7]);
}

void EnvioCAN::envioBorraEscenario(String cadenaMqtt, CAN_frame_t *estructuraCAN){
  
  //PRIMER BYTE ENVIO CAN
  estructuraCAN->data.u8[0] = cadenaMqtt[2];            //INSTRUCCIÓN
  Serial.print(char(estructuraCAN->data.u8[0]));
  //SEGUNDO BYTE ENVIO CAN
  tarjetaEnlace[0] = cadenaMqtt[0];
  tarjetaEnlace[1] = cadenaMqtt[1];
  dirCAN = x2i(tarjetaEnlace);
  estructuraCAN->data.u8[1] = dirCAN;             //DIRECCION DE TARJETA ENLACE
  Serial.print( estructuraCAN->data.u8[1]);
  //TERCER BYTE ENVIO CAN
  numeroEscenario[0] = cadenaMqtt[8];             //NUMERO DE ESCENARIO
  numeroEscenario[1] = cadenaMqtt[9];
  numEscenario = atoi(numeroEscenario);
  estructuraCAN->data.u8[2] = numEscenario;
  Serial.print(estructuraCAN->data.u8[2]);
  //QUINTO BYTE ENVIO CAN
  for(byte i=0; i<5; i++){
    estructuraCAN->data.u8[3+i] = 'x';
    Serial.print(estructuraCAN->data.u8[3+i]);
  }
}

void EnvioCAN::envioConfiguracionTarjetaEntrada(String cadenaConfiguracion, CAN_frame_t *estructuraCAN){

  char tarjetaAccion[3];
  byte dirAccion;
  
  //PRIMER BYTE ENVIO CAN
  estructuraCAN->data.u8[0] = cadenaConfiguracion[2];
  Serial.print(char(estructuraCAN->data.u8[0]));
  //SEGUNDO BYTE ENVIO CAN
  tarjetaEnlace[0] = cadenaConfiguracion[0];
  tarjetaEnlace[1] = cadenaConfiguracion[1];
  dirCAN = x2i(tarjetaEnlace);
  estructuraCAN->data.u8[1] = dirCAN;
  Serial.print(estructuraCAN->data.u8[1]);

  //TERCER BYTE ENVIO CAN
  tarjetaAccion[0] = cadenaConfiguracion[10];
  tarjetaAccion[1] = cadenaConfiguracion[11];
  dirAccion = x2i(tarjetaAccion);
  estructuraCAN->data.u8[2] = dirAccion;
  Serial.print(estructuraCAN->data.u8[2]);
  if(cadenaConfiguracion[12] == 'E'){                   //CASO ESCENARIO
    //CUARTO BYTE ENVIO CAN
    numeroEscenario[0] = cadenaConfiguracion[15];
    numeroEscenario[1] = cadenaConfiguracion[16];
    numEscenario = atoi(numeroEscenario);
    estructuraCAN->data.u8[3] = numEscenario;
    Serial.print(estructuraCAN->data.u8[3]);
    //RESTO
    for(byte l=0; l<4; l++){
      estructuraCAN->data.u8[4+l] = 'x';
      Serial.print(char(estructuraCAN->data.u8[4+l]));
    }
    Serial.println("ESCENARIO");
  }
  else{                                               //CASO ACTIVAR/DESACTIVAR
    //CUARTO BYTE ENCIO CAN
    estructuraCAN->data.u8[3] = cadenaConfiguracion[12];
    Serial.print(char(estructuraCAN->data.u8[3]));
    //QUINTO BYTE ENVIO CAN
    tiempo[0] = cadenaConfiguracion[16];
    tiempo[1] = cadenaConfiguracion[17];
    tiempoByte = atoi(tiempo);
    estructuraCAN->data.u8[4] = tiempoByte;
    Serial.print(estructuraCAN->data.u8[4]);
    if(cadenaConfiguracion[15] == 'x'){                   //CASO RGB
      //SEXTO BYTE ENVIO CAN
      estructuraCAN->data.u8[5] = cadenaConfiguracion[18];
      Serial.print(char(estructuraCAN->data.u8[5]));
      //SEPTIMO BYTE ENVIO CAN
      estructuraCAN->data.u8[6] = cadenaConfiguracion[19];
      Serial.print(char(estructuraCAN->data.u8[6]));
      //OCTAVO BYTE ENVIO CAN
      estructuraCAN->data.u8[7] = cadenaConfiguracion[20];
      Serial.print(char(estructuraCAN->data.u8[7]));
      Serial.println("RGB");
    }
    else{                                               //CASO FOCO
      //SEXTO BYTE ENVIO CAN
      porcentaje[0] = cadenaConfiguracion[13];
      porcentaje[1] = cadenaConfiguracion[14];
      porcentaje[2] = cadenaConfiguracion[15];
      porcentajeByte = atoi(porcentaje);
      estructuraCAN->data.u8[5] = porcentajeByte;
      Serial.print(estructuraCAN->data.u8[5]);
      //RESTO
      for(byte n=0; n<2; n++){
        estructuraCAN->data.u8[6+n];
        Serial.print(estructuraCAN->data.u8[6+n]);
      }
      Serial.println("FOCO");
    }
  }
}
